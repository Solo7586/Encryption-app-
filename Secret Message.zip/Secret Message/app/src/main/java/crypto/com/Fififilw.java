package crypto.com;

import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;

public class Fififilw {

	private static final String FILE_NAME = "data.json";

	// Method to write data to a JSON file based on a key
	public static void writeDataToFile(Context context, String key, String textData) {
		try {
			// Read the existing JSON object from the file
			JSONObject jsonObject = readJsonObjectFromFile(context);

			// Update or add the data for the specified key
			jsonObject.put(key, textData);
			// Write the updated JSON object back to the file
			writeJsonObjectToFile(context, jsonObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Method to read data from a JSON file based on a key
	public static String readDataFromFile(Context context, String key) {
		try {
			// Read the JSON object from the file
			JSONObject jsonObject = readJsonObjectFromFile(context);

			// Retrieve the data for the specified key
			return jsonObject.optString(key, "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	// Method to read a JSON object from the file
	private static JSONObject readJsonObjectFromFile(Context context) throws IOException, JSONException {
		// Get the file path for the JSON file
		File file = new File(context.getFilesDir(), FILE_NAME);
		JSONObject jsonObject = new JSONObject();

		// Check if the file exists
		if (file.exists()) {
			// Read the content of the file and parse it into a JSON object
			try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
				StringBuilder stringBuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					stringBuilder.append(line);
				}
				// Convert the JSON string to a JSON object
				jsonObject = new JSONObject(stringBuilder.toString());
			}
		}

		return jsonObject;
	}

	// Method to write a JSON object to the file
	private static void writeJsonObjectToFile(Context context, JSONObject jsonObject) throws IOException {
		File file = new File(context.getFilesDir(), FILE_NAME);
		try (FileWriter fileWriter = new FileWriter(file)) {
			fileWriter.write(jsonObject.toString());
			fileWriter.flush();
		}
	}
}
