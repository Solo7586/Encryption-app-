package crypto.com;

import android.content.Context;
import android.util.Base64;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES {

	private static AES instance = null;
	private Context mContext;
	private String gg, kk;

	private AES(Context context) {
		mContext = context;
		gg = mContext.getResources().getString(R.string.Eueas);
		kk = mContext.getResources().getString(R.string.Byts);
	}

	public static AES getInstance(Context context) {
		if (instance == null) {
			instance = new AES(context);
		}
		return instance;
	}

	public String encrypt(String message, String key, String IV)
			throws NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException,
			InvalidKeyException, UnsupportedEncodingException, InvalidAlgorithmParameterException {
		try {
			byte[] srcBuff = message.getBytes(kk);
			SecretKeySpec skeySpec = new SecretKeySpec(key.substring(0, 32).getBytes(), "AES");
			IvParameterSpec ivSpec = new IvParameterSpec(IV.substring(0, 16).getBytes());
			Cipher ecipher = Cipher.getInstance(gg);
			ecipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivSpec);
			byte[] dstBuff = ecipher.doFinal(srcBuff);
			return Base64.encodeToString(dstBuff, Base64.DEFAULT);
		} catch (Exception e) {
			throw new RuntimeException("Encryption error: " + e.getMessage(), e);
		}
	}

	public String decrypt(String encrypted, String key, String IV) throws NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
			BadPaddingException, UnsupportedEncodingException {
		try {
			SecretKeySpec skeySpec = new SecretKeySpec(key.substring(0, 32).getBytes(), "AES");
			IvParameterSpec ivSpec = new IvParameterSpec(IV.substring(0, 16).getBytes());
			Cipher ecipher = Cipher.getInstance(gg);
			ecipher.init(Cipher.DECRYPT_MODE, skeySpec, ivSpec);
			byte[] raw = Base64.decode(encrypted.getBytes(), Base64.DEFAULT);
			byte[] originalBytes = ecipher.doFinal(raw);
			return new String(originalBytes, kk);
		} catch (BadPaddingException e) {
			throw new RuntimeException("Decryption error: The input data might be corrupted or incorrect.", e);
		} catch (Exception e) {
			throw new RuntimeException("Decryption error: " + e.getMessage(), e);
		}
	}
}