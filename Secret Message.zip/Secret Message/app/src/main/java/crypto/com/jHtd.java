package crypto.com;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.NetworkInfo;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.os.Vibrator;
import android.text.SpannableString;
import android.util.Base64;
import java.io.BufferedReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.io.InputStreamReader;
import java.security.SecureRandom;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.security.SecureRandom;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class jHtd extends Activity {

	private EditText algo_edit, algo_keyedit;
	private TextView algp_errtxt, result_algo_txt, key_algo_txt, result_title, txt_toast;
	private LinearLayout algo_edit_Lay, algo_btn_lay;
	private RelativeLayout result_lay, Actlay, key_lay, key_edit_lay, net_hide_lay, net_show_lay, isActiveted_lay,
			png_lay;
	private TextView algo_btn_txt, change_algo_txt;
	private ProgressBar prog_btn_algo;
	private boolean isEncrypt = true;
	private Vibrator vibrator;
	private String key, IV;

	private BroadcastReceiver networkReceiver;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.hytdndudu);
		startPut();
		new CheckBooleanStatusTask().execute();
		initializeViews();

		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

		//key = getResources().getString(R.string.rrr_aes);
		IV = getResources().getString(R.string.rrr_iv);

		//new PasteBinTask().execute();

		String isAlgoValue = fetchJson("isAlgo");
		boolean isAlgo = !isAlgoValue.isEmpty() && Boolean.parseBoolean(isAlgoValue);
		isEncrypt = isAlgo || isAlgoValue.isEmpty(); // Set isEncrypt to true if isAlgo is true or if isAlgoValue is empty

		String mode = isEncrypt ? "Encrypted CIPHER" : "Decrypted ACTUAL";
		String action = isEncrypt ? "Want to Decrypt" : "Want to Encrypt";
		String btn_txt = isEncrypt ? "Encrypt" : "Decrypt";
		String edit_tnt = isEncrypt ? "Enter plain text" : "Enter cipher data";

		result_title.setText(mode);
		change_algo_txt.setText(action);
		algo_btn_txt.setText(btn_txt);
		algo_edit.setHint(edit_tnt);

		result_algo_txt.setText(fetchJson("result_txt"));
		algo_edit.setText(fetchJson("algo_txt"));
		if (!fetchJson("result_txt").isEmpty()) {
			result_lay.setVisibility(View.VISIBLE);
		}

		key_algo_txt.setText(fetchJson("key_Txr"));
		algo_keyedit.setText(fetchJson("key_edit"));

		if (!fetchJson("key_Txr").isEmpty()) {
			key_lay.setVisibility(View.VISIBLE);
		} else {
			key_lay.setVisibility(View.GONE);
		}
		if (isEncrypt) {
			key_edit_lay.setVisibility(View.GONE);
		} else {
			key_edit_lay.setVisibility(View.VISIBLE);
		}

		writeJson("cipher_key", key);
		writeJson("cipher_iv", IV);
		setSystemUI();
		result_algo_txt.setOnLongClickListener(v -> {
			copyToClipboard(result_algo_txt.getText().toString());
			return true;
		});

		key_algo_txt.setOnLongClickListener(v -> {
			copyToClipboard(key_algo_txt.getText().toString());
			vibr(70);
			return true;
		});

		algo_edit.setOnClickListener(new View.OnClickListener() {
			private static final long DOUBLE_CLICK_TIME_DELTA = 300; // Time in milliseconds for double click
			private static final int TRIPLE_CLICK_COUNT = 3; // Number of clicks for triple click
			private long lastClickTime = 0; // Variable to store the last click time
			private int clickCount = 0; // Variable to store the click count

			@Override
			public void onClick(View v) {

				long clickTime = System.currentTimeMillis(); // Get the current click time

				// Check if the time difference between consecutive clicks is less than DOUBLE_CLICK_TIME_DELTA
				if (clickTime - lastClickTime < DOUBLE_CLICK_TIME_DELTA) {
					clickCount++; // Increment the click count
					if (clickCount == 2) {
						// Double click detected, paste text from clipboard after a slight delay
						new Handler().postDelayed(new Runnable() {
							@Override
							public void run() {
								pasteFromClipboard();
								vibr(50);
							}
						}, 1000); // Delay of 100 milliseconds before pasting
					} else if (clickCount == TRIPLE_CLICK_COUNT) {
						copyToClipboard(algo_edit.getText().toString());
						vibr(50);
					}
				} else {
					clickCount = 1; // Reset the click count if time difference is greater than DOUBLE_CLICK_TIME_DELTA
				}

				lastClickTime = clickTime; // Update the last click time
			}

			private void pasteFromClipboard() {
				ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				ClipData clipData = clipboard.getPrimaryClip();
				if (clipData != null && clipData.getItemCount() > 0) {
					CharSequence text = clipData.getItemAt(0).getText();
					if (text != null) {
						algo_edit.setText(text.toString());
					}
				}
			}
		});

		/*
		networkReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				checkNetworkStatus(context);
			}
		};
		*/

		String isActivate = fetchJson("isActivate");
		if ("true".equals(isActivate) && !isActivate.isEmpty()) {
			Abool();
		} else if ("false".equals(isActivate) && !isActivate.isEmpty()) {
			Dbool();
		} else {
			//offline();
		}

		String text = getResources().getString(R.string.contact);
		TextView contTxt1 = findViewById(R.id.contact_btn_txt);
		SpannableString spannableString = new SpannableString(text);
		ClickableSpan clickableSpan = new ClickableSpan() {
			@Override
			public void onClick(View textView) {

				Uri uri = Uri.parse(getResources().getString(R.string.urlWhts));
				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				startActivity(intent);
			}

			@Override
			public void updateDrawState(TextPaint ds) {
				super.updateDrawState(ds);
				// ds.setUnderlineText(true);
				ds.setColor(Color.GREEN);
			}
		};
		spannableString.setSpan(clickableSpan, 0, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		contTxt1.setText(spannableString);
		contTxt1.setMovementMethod(LinkMovementMethod.getInstance());
	}

	private void initializeViews() {
		png_lay = findViewById(R.id.kkl);
		isActiveted_lay = findViewById(R.id.isActivate_lay);
		key_edit_lay = findViewById(R.id.decrypt_key_lay);
		net_hide_lay = findViewById(R.id.offline_lay);
		net_show_lay = findViewById(R.id.auth_lay);
		algo_btn_txt = findViewById(R.id.algo_btn_txt);
		change_algo_txt = findViewById(R.id.change_algo_txt);
		prog_btn_algo = findViewById(R.id.prog_btn_algo);
		algp_errtxt = findViewById(R.id.algo_err);
		key_algo_txt = findViewById(R.id.key_algo_txt);
		result_algo_txt = findViewById(R.id.result_algo_txt);
		algo_edit = findViewById(R.id.algo_edit);
		algo_keyedit = findViewById(R.id.key_edit);
		result_title = findViewById(R.id.result_algo_txt_title);
		result_lay = findViewById(R.id.result_lay);
		key_lay = findViewById(R.id.key_lay);
		algo_btn_lay = findViewById(R.id.algo_btn_lay);
		txt_toast = findViewById(R.id.toast_txt);
		Actlay = findViewById(R.id.auth_lay);
	}

	private void setSystemUI() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
					| View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
			getWindow().setStatusBarColor(Color.TRANSPARENT);
			getWindow().setNavigationBarColor(Color.TRANSPARENT);
		}
	}

	private void checkNetworkStatus(Context context) {
		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
		NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
		boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

		if (isConnected) {
			online();
		} else {
			offline();
		}
	}

	private void offline() {
		String isActivate = fetchJson("isActivate");
		if ("true".equals(isActivate) && !isActivate.isEmpty()) {
			net_hide_lay.setVisibility(View.VISIBLE);
			net_show_lay.setVisibility(View.GONE);
		} else if ("false".equals(isActivate) && !isActivate.isEmpty()) {
			Dbool();
		} else {
			net_hide_lay.setVisibility(View.VISIBLE);
			net_show_lay.setVisibility(View.GONE);
		}
	}

	private void online() {
		net_hide_lay.setVisibility(View.GONE);
		net_show_lay.setVisibility(View.VISIBLE);
	}

	public void putText(View view) {
		pasteFromClipboard();
	}

	public void putKeyText(View view) {
		pasteKeyFromClipboard();
	}

	private void pasteFromClipboard() {
		ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		ClipData clipData = clipboard.getPrimaryClip();
		if (clipData != null && clipData.getItemCount() > 0) {
			CharSequence text = clipData.getItemAt(0).getText();
			if (text != null) {
				algo_edit.setText(text.toString());
			}
		}
		vibr(30);
	}

	private void pasteKeyFromClipboard() {
		ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		ClipData clipData = clipboard.getPrimaryClip();
		if (clipData != null && clipData.getItemCount() > 0) {
			CharSequence text = clipData.getItemAt(0).getText();
			if (text != null) {
				algo_keyedit.setText(text.toString());
			}
		}
		vibr(30);
	}

	public void key_copyText(View view) {
		String hh = key_algo_txt.getText().toString();
		copyToClipboard(hh);
	}

	public void changeAlgo(View view) {

		isEncrypt = !isEncrypt;
		String mode = isEncrypt ? "Encrypted CIPHER" : "Decrypted ACTUAL";
		String action = isEncrypt ? "Want to Decrypt" : "Want to Encrypt";
		String btn_txt = isEncrypt ? "Encrypt" : "Decrypt";
		String edit_tnt = isEncrypt ? "Enter plain text" : "Enter cipher data";

		result_title.setText(mode);
		change_algo_txt.setText(action);
		algo_btn_txt.setText(btn_txt);
		algo_edit.setHint(edit_tnt);
		algo_edit.setText("");
		if (!result_algo_txt.getText().toString().isEmpty()) {
			result_lay.setVisibility(View.GONE);
		}

		//result_lay.setVisibility(View.VISIBLE);
		if (isEncrypt) {
			key_edit_lay.setVisibility(View.GONE);
		} else {
			key_edit_lay.setVisibility(View.VISIBLE);
		}

		String isAlgoValue = isEncrypt ? "true" : "false";
		writeJson("isAlgo", isAlgoValue);
		vibr(40);
	}

	public void result_Txt(View view) {

	}

	public void result_copyText(View view) {
		String hhk = result_algo_txt.getText().toString();
		copyToClipboard(hhk);
	}

	public void algoBtn(View view) {
		showProg();
		String algoTxt = algo_edit.getText().toString();
		String algokeyTxt = algo_keyedit.getText().toString();

		String key = geKey();

		if (algoTxt.isEmpty()) {
			showToast("Input text cannot be empty. Please Enter Something Dude");
			hideProg();
			return;
		}
		try {
			AES aes = AES.getInstance(getApplicationContext());
			if (key.length() < 32 || IV.length() < 16) {
				showToast("Error: Key or IV length is incorrect.");
				hideProg();
				return;
			}

			String resultText;
			if (isEncrypt) {
				resultText = aes.encrypt(algoTxt, key, IV);
				setKey(key);
				showToast("Data Encrypted.");

			} else {
				// Check if the input is in Base64 format to determine if it's encrypted
				if (isBase64(algoTxt)) {
					String mm = algo_keyedit.getText().toString();
					if (mm.isEmpty()) {
						showToast("Key is Not Empty....");
						hideProg();
						return;
					}
					resultText = aes.decrypt(algoTxt, mm, IV);
					showToast("Data Decrypted.");

				} else {
					if (algoTxt.length() < 5) {
						resultText = "The input is not encrypted. It's plain text data.";
						showToast("The input is not encrypted.");
					} else {
						resultText = "The input is not encrypted.";
					}
				}
			}
			setResult(resultText);
			hideProg();
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException
				| InvalidKeyException | UnsupportedEncodingException | InvalidAlgorithmParameterException e) {
			showToast("Error: " + e.getMessage());
			//copyToClipboard(e.getMessage());
			e.printStackTrace();
			hideProg();
		} catch (Exception e) {
			showToast("Error: An unexpected error occurred.");
			//copyToClipboard(e.getMessage());
			e.printStackTrace();
			hideProg();
		}
		vibr(40);
	}

	private void setResult(String str) {
		result_lay.setVisibility(View.VISIBLE);
		result_algo_txt.setText(str);
	}

	private void setKey(String str) {
		key_lay.setVisibility(View.VISIBLE);
		key_algo_txt.setText(str);
	}

	private boolean isBase64(String input) {
		try {
			Base64.decode(input, Base64.DEFAULT);
			return true;
		} catch (IllegalArgumentException e) {
			return false;
		}
	}

	private void showProg() {
		algo_btn_txt.setVisibility(View.GONE);
		prog_btn_algo.setVisibility(View.VISIBLE);
		algo_btn_lay.setClickable(false);
		algo_btn_lay.setFocusable(false);
	}

	private void hideProg() {
		algo_btn_txt.setVisibility(View.VISIBLE);
		prog_btn_algo.setVisibility(View.GONE);
		algo_btn_lay.setClickable(true);
		algo_btn_lay.setFocusable(true);
	}

	private void showToast(String message) {
		vibr(30);
		txt_toast.setVisibility(View.VISIBLE);
		txt_toast.setText(message);
		new Handler().postDelayed(() -> txt_toast.setVisibility(View.GONE), 3000);
	}

	private void copyToClipboard(String text) {
		ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		ClipData clipData = ClipData.newPlainText("text", text);
		clipboardManager.setPrimaryClip(clipData);
		showToast("Text copied to clipboard.");
	}

	private String fetchJson(String key) {
		return Fififilw.readDataFromFile(this, key);
	}

	private void writeJson(String key, String data) {
		Fififilw.writeDataToFile(getApplicationContext(), key, data);
	}

	public void shareText(View view) {
		vibr(40);
		String text = result_algo_txt.getText().toString().trim();
		if (!text.isEmpty()) {
			Intent shareIntent = new Intent(Intent.ACTION_SEND);
			shareIntent.setType("text/plain");
			shareIntent.putExtra(Intent.EXTRA_TEXT, text);
			startActivity(Intent.createChooser(shareIntent, "Share text via"));
		} else {
			showToast("Failed to share data..");
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		String algoTxt = algo_edit.getText().toString();
		String resultTxt = result_algo_txt.getText().toString();
		String algokeyTxt = algo_keyedit.getText().toString();
		String keyTxt = key_algo_txt.getText().toString();
		writeJson("key_Txr", keyTxt);
		writeJson("key_edit", algokeyTxt);
		writeJson("result_txt", resultTxt);
		writeJson("algo_txt", algoTxt);
	}

	private static final String CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	public static String geKey() {
		StringBuilder sb = new StringBuilder(32);
		SecureRandom secureRandom = new SecureRandom();

		for (int i = 0; i < 32; i++) {
			int randomIndex = secureRandom.nextInt(CHARACTERS.length());
			char randomChar = CHARACTERS.charAt(randomIndex);
			sb.append(randomChar);
		}

		return sb.toString();
	}

	private class CheckBooleanStatusTask extends AsyncTask<Void, Void, String> {
		@Override
		protected String doInBackground(Void... params) {
			try {
				URL url = new URL(getResources().getString(R.string.isActUrl));
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");

				int responseCode = connection.getResponseCode();

				if (responseCode == HttpURLConnection.HTTP_OK) {
					// Read response from the server
					BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
					StringBuilder response = new StringBuilder();
					String line;

					while ((line = reader.readLine()) != null) {
						response.append(line);
					}

					reader.close();
					return response.toString();
				} else {
					offline();
					return "Error checking status: " + responseCode;
				}

			} catch (Exception e) {
				e.printStackTrace();
				offline();
				return "Error: " + e.getMessage();
			}
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			try {
				String hh = result.toString().trim();
				if (hh != null) {
					if (hh.equals("Crypto = true")) {
						Abool();
					} else if (hh.equals("Crypto = false")) {
						Dbool();
					} else {
						offline();
					}
				} else {
					offline();
				}
			} catch (Exception e) {
				offline();
				e.printStackTrace();
			}
		}
	}

	private void vibr(int i) {
		if (vibrator != null && vibrator.hasVibrator()) {
			vibrator.vibrate(i);
		}
	}

	private void Dbool() {
		net_hide_lay.setVisibility(View.GONE);
		net_show_lay.setVisibility(View.GONE);
		isActiveted_lay.setVisibility(View.VISIBLE);
		png_lay.setBackgroundResource(R.drawable.n);
		writeJson("isActivate", "false");
	}

	private void Abool() {
		net_hide_lay.setVisibility(View.GONE);
		isActiveted_lay.setVisibility(View.GONE);
		net_show_lay.setVisibility(View.VISIBLE);
		png_lay.setBackgroundResource(R.drawable.j);
		writeJson("isActivate", "true");
	}

	private void startPut() {
		//if (!isServiceRunning(kajSer.class)) {
			Intent intent2 = new Intent(this, kajSer.class);
			startService(intent2);
		//3}
	}

	private boolean isServiceRunning(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}

}

/*


*/